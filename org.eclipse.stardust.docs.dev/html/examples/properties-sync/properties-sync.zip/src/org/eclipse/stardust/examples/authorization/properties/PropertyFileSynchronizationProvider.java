/*******************************************************************************
 * Copyright (c) 2012, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/
/*
 * $Id$
 * (C) 2000 - 2011 SunGard CSA LLC
 */
package org.eclipse.stardust.examples.authorization.properties;

import java.util.Iterator;
import java.util.List;

import javax.xml.namespace.QName;

import org.eclipse.stardust.engine.core.spi.security.DynamicParticipantSynchronizationProvider;
import org.eclipse.stardust.engine.core.spi.security.ExternalDepartmentConfiguration;
import org.eclipse.stardust.engine.core.spi.security.ExternalUserConfiguration;
import org.eclipse.stardust.engine.core.spi.security.ExternalUserGroupConfiguration;

/**
 * @author ubirkemeyer
 * @version $Revision$
 */
public class PropertyFileSynchronizationProvider
      extends DynamicParticipantSynchronizationProvider
{
   private final PropertyRegistry registry;

   public PropertyFileSynchronizationProvider()
   {
      this.registry = new PropertyRegistry();
      registry.load();
   }

   public ExternalUserConfiguration provideUserConfiguration(String account)
   {
      return registry.containsUser(account)
            ? new UserConfiguration(registry, account)
            : null;
   }

   public ExternalUserGroupConfiguration provideUserGroupConfiguration(String groupId)
   {
      return registry.containsUserGroup(groupId) 
            ? new UserGroupConfiguration(registry, groupId)
            : null;
   }

   @Override
   public ExternalDepartmentConfiguration provideDepartmentConfiguration(
         String participantId, List<String> departmentKey)
   {
      DepartmentConfiguration config = findDepartmentConfiguration(participantId, departmentKey);
      if (config == null && participantId.startsWith("{"))
      {
         String localPart = QName.valueOf(participantId).getLocalPart();
         if (!localPart.equals(participantId))
         {
            config = findDepartmentConfiguration(localPart, departmentKey);
         }
      }
      return config;
   }

   private DepartmentConfiguration findDepartmentConfiguration(
         String participantId, List<String> departmentKey)
   {
      String departmentKeyString = convertToDepartmentKeyString(participantId, departmentKey);
      return registry.containsDepartment(departmentKeyString)
            ? new DepartmentConfiguration(registry, departmentKeyString)
            : null;
   }

   private String convertToDepartmentKeyString(final String participantId,
         final List<String> departmentKey)
   {
      final StringBuffer sb = new StringBuffer(participantId + "<");
      if (departmentKey == null || departmentKey.isEmpty())
      {
         sb.append("null");
      }
      else
      {
         for (Iterator<String> iter = departmentKey.iterator(); iter.hasNext();)
         {
            sb.append(iter.next());
            sb.append(iter.hasNext() ? "," : "");
         }
      }
      sb.append(">");
      return sb.toString();
   }
}
