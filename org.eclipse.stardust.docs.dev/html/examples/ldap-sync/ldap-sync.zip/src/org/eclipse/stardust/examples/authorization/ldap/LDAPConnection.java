/*******************************************************************************
 * Copyright (c) 2012, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/
/*
 * $Id$
 * (C) 2000-2011 SunGard CSA LLC
 */
package org.eclipse.stardust.examples.authorization.ldap;

import java.util.Hashtable;

import javax.naming.AuthenticationException;
import javax.naming.CommunicationException;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

import org.eclipse.stardust.common.StringUtils;
import org.eclipse.stardust.common.config.Parameters;
import org.eclipse.stardust.common.error.InternalException;
import org.eclipse.stardust.common.error.LoginFailedException;
import org.eclipse.stardust.engine.api.runtime.BpmRuntimeError;



/**
 * Abstracts a session to an LDAP server.
 * 
 * @author swoelk
 */
public final class LDAPConnection
{
   /**
    * Holds a reference to the JNDI environment hash
    */
   private Hashtable<String, String> contextEnvironment = null;

   /**
    * Holds a dir context reference that is associated with this connection
    */
   private DirContext dirContext = null;

   /**
    * Holds the default host name of the LDAP server
    */
   private final static String ldapServerHost = Parameters.instance().getString(
         LDAPProperties.LDAP_SERVER_HOST_PROPERTY);

   /**
    * Holds the default port of the ldap server
    */
   private final static int ldapServerPort = Parameters.instance().getInteger(
         LDAPProperties.LDAP_SERVER_PORT_PROPERTY, 389);

   /**
    * Holds the default root dn
    */
   private final static String rootDN = Parameters.instance().getString(
         LDAPProperties.ROOT_DN_PROPERTY);

   /**
    * Constructs an LDAPConnection object without user information.
    * If connect() is called on an instance created with this constructor
    * and not calling setUserInfo() in any way the resulting connection is
    * anonymous.
    * 
    * @param providerURL
    */
   public LDAPConnection(String providerURL)
   {
      initialize(providerURL);
   }

   /**
    * Set the userDN and the password for an LDAPConnection. The values are
    * stored directly in the hashtable.
    * 
    * @param userDN
    * @param password
    */
   public void setUserInfo(String userDN, String password)
   {
      contextEnvironment.put(Context.SECURITY_PRINCIPAL, userDN);
      contextEnvironment.put(Context.SECURITY_CREDENTIALS, password);
   }

   /**
    * This method returns the DirContext associated with this connection (if
    * any)
    * @return the DirContext associated with this connection
    */
   public DirContext getContext()
   {
      connect();
      return dirContext;
   }

   /**
    * Creates a connection to an LDAP server. This is done by instantiating a
    * new InitialDirContext with the supplied environment hashtable and stores a
    * reference to the context in an instance variable.
    */
   private void connect()
   {

      if (dirContext != null)
      {
         return;
      }

      try
      {
         dirContext = new InitialDirContext(contextEnvironment);
      }
      catch (AuthenticationException ae)
      {
         throw new LoginFailedException(
               BpmRuntimeError.LOGIN_LDAP_INVALID_USER_PASSWORD.raise(),
               LoginFailedException.AUTHORIZATION_FAILURE);
      }
      catch (CommunicationException ne)
      {
         throw new LoginFailedException(
               BpmRuntimeError.LOGIN_LDAP_UNABLE_TO_CONNECT.raise(),
               LoginFailedException.SYSTEM_ERROR);
      }
      catch (NamingException ne)
      {
         throw new LoginFailedException(
               BpmRuntimeError.LOGIN_LDAP_NAMING_EXCEPTION.raise(ne.getMessage(), ne
                     .getClass().getName()), LoginFailedException.SYSTEM_ERROR);
      }

   }

   /**
    * Drops this connection to the LDAP server. The DirContext is closed and the
    * instance variable is set to null, to give garbage collection a job.
    */
   public void disconnect()
   {
      try
      {
         if (dirContext != null)
         {
            dirContext.close();
         }
         dirContext = null;
      }
      catch (NamingException ne)
      {
      }
   }

   /**
    * Tests whether there is a valid connection.
    * 
    * @return true, if there is a dir context and therefore a connection
    */
   public boolean isConnected()
   {
      return (dirContext != null);
   }

   /**
    * This method initializes the context environment hashtable. It set the
    * provider URL and some factory classes.
    * 
    * @param providerURL
    */
   private void initialize(String providerURL)
   {
      if (providerURL == null)
      {
         if (StringUtils.isEmpty(ldapServerHost) || StringUtils.isEmpty(rootDN))
         {
            throw new InternalException("No provider URL passed");
         }
         providerURL = "ldap://" + ldapServerHost + ":" + ldapServerPort + "/" + rootDN;
      }

      contextEnvironment = new Hashtable<String, String>();
      contextEnvironment.put(Context.INITIAL_CONTEXT_FACTORY,
            "com.sun.jndi.ldap.LdapCtxFactory");
      contextEnvironment.put(Context.PROVIDER_URL, providerURL);
   }
}
