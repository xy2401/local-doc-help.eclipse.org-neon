********************************************

Multi Model Audit Trail Setups Example

Copyright (c) 2014 SunGard CSA LLC and others.
All rights reserved. This program and the accompanying materials
are made available under the terms of the Eclipse Public License v1.0
which accompanies this distribution, and is available at
_http://www.eclipse.org/legal/epl-v10.html
Contributors:
SunGard CSA LLC - initial API and implementation and/or initial documentation

********************************************

The example models provided in this section demonstrate multi-modeling using 
our product.

Tutorial

Please find the according tutorial in the Tutorial Guide of the documentation:

 * Working with Provider and Consumer Models
     - explains how to do multi-modeling in one audit trail database.
