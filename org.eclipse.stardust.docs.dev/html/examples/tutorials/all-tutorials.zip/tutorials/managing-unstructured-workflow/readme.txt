********************************************

Managing Unstructured Workflows Example

Copyright (c) 2014 SunGard CSA LLC and others.
All rights reserved. This program and the accompanying materials
are made available under the terms of the Eclipse Public License v1.0
which accompanies this distribution, and is available at
_http://www.eclipse.org/legal/epl-v10.html
Contributors:
SunGard CSA LLC - initial API and implementation and/or initial documentation

********************************************

The example models provided in this section provide several process definitions 
supporting process attachments and containing a Scan trigger. These models can 
be used to demonstrate spawning, pausing and starting, aborting and starting or linking processes as
well as extracting pages.

Please find the according tutorials in the Tutorial Guide of the documentation:

 * Spawning Subprocesses
      - tutorial describing how spawning of a root process instance
        creates a subprocess and copies data associated with it
 * Extracting Pages Tutorial
      - tutorial to demonstrate how to extract pages from a document attached to
        a process instance and create a new process instance containing the
        extracted pages
 * Aborting and Starting Processes
      - tutorial describing how to abort and start processes.
 * Aborting and Joining Processes
      - tutorial describing how to abort and join new processes
 * Pausing and Starting Processes
 	- tutorial describing how to pause and start processes     
