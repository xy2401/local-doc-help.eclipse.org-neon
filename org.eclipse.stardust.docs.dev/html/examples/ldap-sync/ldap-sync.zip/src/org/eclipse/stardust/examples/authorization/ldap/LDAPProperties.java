/*******************************************************************************
 * Copyright (c) 2012, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/
/*
 * $Id$
 * (C) 2000 - 2011 SunGard CSA LLC
 */
package org.eclipse.stardust.examples.authorization.ldap;

import javax.naming.directory.SearchControls;

/**
 * Collects the property names used for the configuration.
 * 
 * @author ubirkemeyer
 * @version $Revision$
 */
public class LDAPProperties
{
   /**
    * The name of the property that specifies the DNS name or IP address of the LDAP
    * server
    */
   public static final String LDAP_SERVER_HOST_PROPERTY = "LDAPSynchronization.ServerName";

   /**
    * The name of the property that specifies the port on which the server software is
    * listening for incoming connections.
    */
   public static final String LDAP_SERVER_PORT_PROPERTY = "LDAPSynchronization.ServerPort";

   /**
    * <p>
    * The name of the property that specifies the root DN to which the InitialDirContext
    * will be created in an LDAPConnection.
    * </p>
    * <p>
    * A company named "ACME" e.g. has the base DN <code>o=ACME,d=com</code>.
    * </p>
    */
   public static final String ROOT_DN_PROPERTY = "LDAPSynchronization.RootDN";

   /**
    * <p>
    * The name of the property that specifies the root used for querying for users
    * relative to the base DN.
    * </p>
    * <p>
    * If for example users are positioned in the directory in a group with the DN
    * <code>ou=User,o=ACME,d=com</code> this property should be set to
    * <code>ou=User</code> (assuming a base DN of <code>o=ACME,d=com</code>).
    * </p>
    */
   public static final String USER_BASE_DN_PROPERTY = "LDAPSynchronization.UserBaseDN";
   
   /**
    * <p>
    * The name of the property that specifies the root used for querying for departments
    * relative to the base DN.
    * </p>
    * <p>
    * If for example departments are positioned in the directory in a group with the DN
    * <code>ou=Departments,o=ACME,d=com</code> this property should be set to
    * <code>ou=Departments</code> (assuming a base DN of <code>o=ACME,d=com</code>).
    * </p>
    */
   public static final String DEPARTMENT_BASE_DN_PROPERTY = "LDAPSynchronization.DepartmentBaseDN";

   /**
    * <p>
    * The name of the property that specifies the root used for querying for groups
    * (participants) relative to the base DN.
    * </p>
    * <p>
    * If for example participants relevant for CARNOT are positioned in the directory in a
    * group with the DN <code>ou=CARNOT,ou=Applications,o=ACME,d=com</code> this
    * property should be set to <code>ou=CARNOT,ou=Applications</code> (assuming a base
    * DN of <code>o=ACME,d=com</code>).
    * </p>
    */
   public static final String GROUP_BASE_DN_PROPERTY = "LDAPSynchronization.GroupBaseDN";

   /**
    * <p>
    * The query scope used for the user query as int value. The values derive from the
    * values given in {@link SearchControls}:
    * <ul>
    * <li> 0: object scope {@link SearchControls#OBJECT_SCOPE}</li>
    * <li> 1: one level scope {@link SearchControls#ONELEVEL_SCOPE}</li>
    * <li> 2: subtree scope {@link SearchControls#SUBTREE_SCOPE}</li>
    * </ul>
    * </p>
    * <p>
    * Default is {@link SearchControls#SUBTREE_SCOPE} (2).
    * </p>
    */
   public static final String USER_QUERY_SCOPE = "LDAPSynchronization.UserQueryScope";

   /**
    * <p>
    * The query scope used for the group query as int value. The values derive from the
    * values given in {@link SearchControls}:
    * <ul>
    * <li> 0: object scope {@link SearchControls#OBJECT_SCOPE}</li>
    * <li> 1: one level scope {@link SearchControls#ONELEVEL_SCOPE}</li>
    * <li> 2: subtree scope {@link SearchControls#SUBTREE_SCOPE}</li>
    * </ul>
    * </p>
    * <p>
    * Default is {@link SearchControls#SUBTREE_SCOPE} (2).
    * </p>
    */
   public static final String GROUP_QUERY_SCOPE = "LDAPSynchronization.GroupQueryScope";

   /**
    * The name of the property that specifies the LDAP data retrieval mode. Possible
    * values are <code>anonymous</code> and <code>dedicated</code>, default is
    * <code>anonymous</code>.
    * 
    */
   public static final String BIND_MODE_PROPERTY = "LDAPSynchronization.BindMode";

   /**
    * The name of the property that specifies the distinguished name of the user account
    * that will be used for the data retrieval connection.
    */
   public static final String BIND_USER_PROPERTY = "LDAPSynchronization.BindUserDN";

   /**
    * The name of the property that specifies the password of the user account that will
    * be used for the data retrieval connection.
    */
   public static final String BIND_PASSWORD_PROPERTY = "LDAPSynchronization.BindPassword";

   /**
    * <p>
    * The filter used to retrieve the participants (usually LDAP groups) that the current
    * user belongs to. "%v" will be replaced by the dn (distinguished name) of the current
    * user.
    * </p>
    * <p>
    * Example: <code>(&(objectClass=groupOfNames)(member=%v))</code><br>
    * For the user "motu" this will be resolved to the query:
    * <code>(&(objectClass=groupOfNames)(member=cn=motu, ou=user, o=ACME, c=com))</code>
    * (given that "motu" is part of the group "user" which is in our base DN "o=ACME,
    * c=com").
    * </p>
    * <p>
    * Base DN for the query is the property <code>GROUP_BASE_DN_PROPERTY</code>
    * </p>
    */
   public static final String PARTICIPANT_FILTER_PROPERTY = "LDAPSynchronization.ParticipantFilter";

   /**
    * <p>
    * The filter used to retrieve the users (usually LDAP persons) that the current user
    * belongs to. "%v" will be replaced by the account of the current user.
    * </p>
    * <p>
    * Example: <code>(&(objectClass=Person)(cn=%v))</code><br>
    * For the user "motu" this will be resolved to the query:
    * <code>(&(objectClass=Person)(cn=motu))</code>.
    * </p>
    * <p>
    * Base DN for the query is the property <code>USER_BASE_DN_PROPERTY</code>
    * </p>
    */
   public static final String USER_FILTER_PROPERTY = "LDAPSynchronization.UserFilter";

   /**
    * <p>
    * The filter used to retrieve the departments that the current user
    * belongs to. "%v" will be replaced by the account of the current user.
    * </p>
    * <p>
    * Example: <code>(&(objectClass=groupOfNames)(cn=%v))</code><br>
    * For the user "motu" this will be resolved to the query:
    * <code>(&(objectClass=groupOfNames)(cn=motu))</code>.
    * </p>
    * <p>
    * Base DN for the query is the property <code>DEPARTMENT_BASE_DN_PROPERTY</code>
    * </p>
    */
   public static final String DEPARTMENT_FILTER_PROPERTY = "LDAPSynchronization.DepartmentFilter";
   
   /**
    * The search time limit for the LDAP query. Default is <code>0</code>.
    */
   public static final String SEARCH_TIME_LIMIT_PROPERTY = "LDAPSynchronization.SearchTimeLimit";

   /**
    * The LDAP attribute that contains to the id of the CARNOT model role. Default is
    * <code>cn</code>.
    */
   public static final String PARTICIPANT_ID_ATT_PROPERTY = "LDAPSynchronization.ParticipantIDAttribute";

   /**
    * The LDAP attribute that contains the account of the user. Default is <code>cn</code>.
    */
   public static final String USER_ACCOUNT_ATT_PROPERTY = "LDAPSynchronization.UserAccountAttribute";

   /**
    * The LDAP attribute that contains the lastname of the user. Default is
    * <code>sn</code>.
    */
   public static final String USER_LASTNAME_ATT_PROPERTY = "LDAPSynchronization.UserLastnameAttribute";

   /**
    * The LDAP attribute that contains the firstname of the user. Default is
    * <code>givenname</code>.
    */
   public static final String USER_FIRSTNAME_ATT_PROPERTY = "LDAPSynchronization.UserFirstnameAttribute";

   /**
    * The LDAP attribute that contains the description of the user. Default is
    * <code>description</code>.
    */
   public static final String USER_DESCRIPTION_ATT_PROPERTY = "LDAPSynchronization.UserDescriptionAttribute";

   /**
    * The LDAP attribute that contains the email of the user. Default is <code>mail</code>.
    */
   public static final String USER_EMAIL_ATT_PROPERTY = "LDAPSynchronization.UserEmailAttribute";

   /**
    * A comma seperated list of attributes that will be copied from the LDAP and stored as
    * CARNOT user properties. This attribute is by default empty.
    */
   public static final String USER_ADDITIONAL_ATT_PROPERTY = "LDAPSynchronization.UserAdditionalAttributes";
   
   /**
    * The LDAP attribute that contains the name of the department. Default is <code>ou</code>.
    */
   public static final String DEPARTMENT_NAME_ATT_PROPERTY = "LDAPSynchronization.DepartmentName";
   
   /**
    * The LDAP attribute that contains the description of the department. Default is
    * <code>description</code>.
    */
   public static final String DEPARTMENT_DESCRIPTION_ATT_PROPERTY = "LDAPSynchronization.DepartmentDescription";
}
