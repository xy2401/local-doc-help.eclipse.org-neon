/*******************************************************************************
 * Copyright (c) 2012, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/
/*
 * $Id: $
 * (C) 2000-2011 SunGard CSA LLC
 */
package org.eclipse.stardust.examples.authorization.ldap;

import org.eclipse.stardust.common.StringUtils;

/**
 * Encapsulates the following information of a
 * department retrieved from an LDAP directory.
 * <ul>
 *    <li>Name</li>
 *    <li>Description</li>
 * </ul>
 * 
 * @author nicolas.werlein
 * @version $Revision: $
 */
public class LDAPDepartment
{
   private final String name;
   private final String description;
   
   /**
    * Creates a department with the given name
    * and description.
    * 
    * @param name the name of the department
    * @param description the description of the department
    * 
    * @throws NullPointerException if name is null
    * @throws IllegalArgumentException if name is empty
    */
   public LDAPDepartment(final String name, final String description)
   {
      if (name == null)
      {
         throw new NullPointerException("name must not be null.");
      }
      if (StringUtils.isEmpty(name))
      {
         throw new IllegalArgumentException("name must not be empty.");
      }
      
      this.name = name;
      this.description = description;
   }
   
   /**
    * Returns the name of the department.
    * 
    * @return the name, never null or empty
    */
   public String getName()
   {
      return name;
   }
   
   /**
    * Returns the description of the department.
    * 
    * @return the description of the department, may be null or empty
    */
   public String getDescription()
   {
      return description;
   }
}
