********************************************

WebLogic SecureSessionFactory Example

Copyright (c) 2014 SunGard CSA LLC and others.
All rights reserved. This program and the accompanying materials
are made available under the terms of the Eclipse Public License v1.0
which accompanies this distribution, and is available at
_http://www.eclipse.org/legal/epl-v10.html
Contributors:
SunGard CSA LLC - initial API and implementation and/or initial documentation

********************************************

This example contains the source code for the WeblogicSecureSessionFactory.

A SecureSessionFactory is responsible for
authenticating the user at an application server. After a successful login to
the application server it returns a session bean. There is no need to
call the login method on this session, if retrieved by a SecureSessionFactory.

Since the mechanisms to authenticate against an application server are
not portable for each application server there has to be an own SecureSessionFactory.
Even different configurations or authentication methods can require different SecureSessionFactory
classes. This is an example of how to authenticate against Oracle WebLogic Server 12c.

For more detailed information on the SecureSessionFactory
interface please refer to chapter "Implementing Custom Security" in the 
Programming Guide of the documentation.

This example can be used in the console module that is created by the Weblogic EAR archetype.
Open the pom.xml which is located in the <wls-ear-archetype-project>/console module and
include the following dependency:
      <dependency>
         <groupId>org.eclipse.stardust.examples</groupId>
         <artifactId>weblogic-auth</artifactId>
         <version>${ipp.version}</version>
      </dependency>
In the carnot.properties of the console module you have to set the Secure.Session.Factory
property to:
Secure.Session.Factory = org.eclipse.stardust.examples.authentication.weblogic.WeblogicSecureSessionFactory
With this change the console tool will use the SecureSessionFactory to authenticate the
user against the application server.

Please note that this example assumes that the Engine is using implicit authentication. Further
details can be found in the Security chapter of the Operation Guide in the documentation.