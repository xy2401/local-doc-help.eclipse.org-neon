********************************************

Java Property File Synchronization Example

Copyright (c) 2014 SunGard CSA LLC and others.
All rights reserved. This program and the accompanying materials
are made available under the terms of the Eclipse Public License v1.0
which accompanies this distribution, and is available at
_http://www.eclipse.org/legal/epl-v10.html
Contributors:
SunGard CSA LLC - initial API and implementation and/or initial documentation

********************************************

This example contains the source code for an example implementation of
both the ExternalLoginProvider and the DynamicParticipantSynchronizationProvider
interface, based on Java property files.

The location of the property file to be used has to be configured by
setting the User.Registry property, which defaults to user-registry.properties.

In general a DynamicParticipantSynchronizationProvider takes
care of retrieving authorization information for an authenticated user as well
as detail about this user itself from an external user registry. This example
shows how to retrieve this information from a plain Java property file.
The general syntax of such user registry property file is:

 * User.$account$.Password
      The most basic entry for a user, its existence marks the user as
      existent. The also provided ExternalLoginProvider implementation may be
      used to authenticate users against this password.
 * User.$account$.FirstName
      Optional property, specifying the users first name.
 * User.$account$.LastName
      Optional property, specifying the users last name.
 * User.$account$.EMail
      Optional property, specifying the users email address.
 * User.$account$.Roles
      Optional property, specifying the model participants granted to the
    user as a comma separated list.
 * User.$account$.UserGroups
      Optional property, specifying the user groups the user is a member
      of as a semicolon separated list. Any user group / department referenced has to be
      defined by an appropriate Group.$id$.Name / Department.$id$.Name entry.
 * Group.$id$.Name
      Required property to define the existence of a user group.
 * Department.$deptId$.Name
      Required property to define the existence of a department. The structure of a 
      $deptId$ is as follows:
      <Organization-Id><>Department-Id>|<null>{<,>Department-Id>|<null>}<>>, e.g. Org2<u,i>, Org3<u,i,null>.
 * Department.$deptId$.Description
      Optional property, specifying the department's description.

For more detailed information on the DynamicParticipantSynchronizationProvider
interface please refer to chapter "Integrating External User Repositories"
of the Programming Guide in the documentation.

This example can be used in projects which are based on the WAR and EAR archetypes. 
For a plain Spring WAR deployment please open the pom.xml of the corresponding project 
into an editor. For EAR deployments you have to use the pom.xml which is located either 
in the config module (JBoss only) or in the ejb module (Weblogic and WebSphere).
After this please include the following dependency there:
      <dependency>
         <groupId>org.eclipse.stardust.examples</groupId>
         <artifactId>properties-sync</artifactId>
         <version>${ipp.version}</version>
         <scope>runtime</scope>
      </dependency>
In a last step the following properties must be included in the server side carnot.properties:
  User.Registry=C:/Development/user-registry-file.properties
  Security.Authentication.LoginService=org.eclipse.stardust.examples.authorization.properties.PropertyFileLoginService
  Security.Authorization.SynchronizationProvider=org.eclipse.stardust.examples.authorization.properties.PropertyFileSynchronizationProvider
  Security.Authorization.SynchronizationStrategy=org.eclipse.stardust.examples.authorization.properties.AlwaysSyncStrategy
whereby the path and the file name of the User.Registry property must be adapted 
according to your environment.

Please note that this example assumes that the Engine is using implicit authentication. Further
details can be found in the Security chapter of the Operation Guide in the documentation.


