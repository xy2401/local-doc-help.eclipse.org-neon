package org.eclipse.stardust.examples.errorcases;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class ActivityInstanceMonitorErrorMessage
{
   private static final String BUNDLE_NAME = "org.eclipse.stardust.examples.errorcases.ipp-activityinstancemonitor-errors"; //$NON-NLS-1$
   private static ResourceBundle resourceBundle;
   
   private ActivityInstanceMonitorErrorMessage()
   {
   }

   public static String getString(String key)
   {
      try
      {
         if(resourceBundle == null)
         {
            resourceBundle = ResourceBundle.getBundle(BUNDLE_NAME);
         }
         
         return resourceBundle.getString(key);
      }
      catch (MissingResourceException e)
      {
         return '!' + key + '!';
      }
   }
   
   
   
   
}
