********************************************

Defining and Running Reports Examples

Copyright (c) 2014 SunGard CSA LLC and others.
All rights reserved. This program and the accompanying materials
are made available under the terms of the Eclipse Public License v1.0
which accompanies this distribution, and is available at
_http://www.eclipse.org/legal/epl-v10.html
Contributors:
SunGard CSA LLC - initial API and implementation and/or initial documentation

********************************************

The example provided in this section guides you through the usage of the
Business Process Reporting perspective. It contains the example model used in 
the tutorial as well as the resulting report definition.

Please find the according tutorial in the Tutorial Guide of the documentation:

 * Defining and Running Reports - Creating a Simple Report Definition
      - a simple use case example on how to use a report definition to get an
      overview on the number of product items that have been sold in a process.
