********************************************

Document Management Service Example

Copyright (c) 2014 SunGard CSA LLC and others.
All rights reserved. This program and the accompanying materials
are made available under the terms of the Eclipse Public License v1.0
which accompanies this distribution, and is available at
_http://www.eclipse.org/legal/epl-v10.html
Contributors:
SunGard CSA LLC - initial API and implementation and/or initial documentation

********************************************

The Document Management Service example folder provides an example process 
model using different Document Management Service operations.

Please refer to chapter "DMS Operation Tutorial" of the Document Service 
Integration Guide for a guidance on how to use the model and to demonstrate the 
usage of document services in our product.


