package org.eclipse.stardust.examples.errorcases;

import org.eclipse.stardust.common.error.PublicException;
import org.eclipse.stardust.common.log.LogManager;
import org.eclipse.stardust.common.log.Logger;
import org.eclipse.stardust.engine.api.query.WorklistQuery;
import org.eclipse.stardust.engine.api.runtime.ActivityInstanceState;
import org.eclipse.stardust.engine.core.runtime.beans.IActivityInstance;
import org.eclipse.stardust.engine.core.spi.monitoring.IActivityInstanceMonitor;

public class ActivityInstanceMonitorTest implements IActivityInstanceMonitor
{

   private static final Logger trace = LogManager.getLogger(WorklistQuery.class);

   @Override
   public void activityInstanceStateChanged(IActivityInstance ai, int state)
   {
      trace.info("Activating SPI for ActivityStateChange");

      if (state == ActivityInstanceState.COMPLETED)
      {         
         throw new PublicException(               
               ActivityInstanceMonitorErrorCase.AIM_GENERIC_ERROR.raise());
      }
      else if (state == ActivityInstanceState.SUSPENDED)
      {
         throw new PublicException(
               ActivityInstanceMonitorErrorCase.AIM_GENERIC_ERROR_WITH_SINGLE_ARG.raise("A custom error happened while suspending ActivityInstance <"
                     + ai + ">"));
      }

   }

}
