********************************************

LDAP Synchronization Example

Copyright (c) 2014 SunGard CSA LLC and others.
All rights reserved. This program and the accompanying materials
are made available under the terms of the Eclipse Public License v1.0
which accompanies this distribution, and is available at
_http://www.eclipse.org/legal/epl-v10.html
Contributors:
SunGard CSA LLC - initial API and implementation and/or initial documentation

********************************************

This example contains the source code for an example implementation of
both the ExternalLoginProvider and the DynamicParticipantSynchronizationProvider
interface, based on an LDAP repository.

The ZIP file contains source code, properties and an LDIF example file.

In general a DynamicParticipantSynchronizationProvider takes care of
retrieving authorization information for an authenticated user and detail data
for this user as well. This example shows how to retrieve this information from
a LDAP repository. Naturally a certain LDAP structure is expected. The example
handles this quite flexible by using LDAP search filters for retrieving users
and participants. The configuration is described in detail in the Operation Guide of 
the documentation.

For more detailed information on the DynamicParticipantSynchronizationProvider
interface please refer to chapter "Implementing Custom Security"
of the Programming Guide in the documentation.

This example can be used in projects which are based on the WAR and EAR archetypes. 
For a plain Spring WAR deployment please open the pom.xml of the corresponding project 
into an editor. For EAR deployments you have to use the pom.xml which is located either 
in the config module (JBoss only) or in the ejb module (Weblogic and WebSphere).
After this please include the following dependency there:
      <dependency>
         <groupId>org.eclipse.stardust.examples</groupId>
         <artifactId>ldap-sync</artifactId>
         <version>${ipp.version}</version>
         <scope>runtime</scope>
      </dependency>
In a last step the following properties must be included in the server side carnot.properties:
  LDAPSynchronization.ServerName=localhost
  LDAPSynchronization.ServerPort=389
  LDAPSynchronization.RootDN=dc=ldap,dc=example,dc=ipp
  LDAPSynchronization.UserBaseDN=ou=People
  LDAPSynchronization.UserFilter=(&#38;(uid=%v)(objectclass=inetOrgPerson))
  LDAPSynchronization.ParticipantFilter=(&#38;(objectClass=groupOfUniqueNames)(uniqueMember=uid=%v*))
  Security.Authorization.SynchronizationProvider=org.eclipse.stardust.examples.authorization.ldap.LDAPSynchronizationProvider
  Security.Authentication.LoginService=org.eclipse.stardust.examples.authorization.ldap.LDAPLoginProvider

whereby the LDAPSynchronization properties must be adjusted according to your environment.

Please note that this example assumes that the Engine is using implicit authentication. Further
details can be found in the Security chapter of the Operation Guide in the documentation.
