/*******************************************************************************
 * Copyright (c) 2000, 2015 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/

package org.eclipse.stardust.examples.authentication.weblogic;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.naming.NamingSecurityException;
import javax.rmi.PortableRemoteObject;

import org.eclipse.stardust.common.config.Parameters;
import org.eclipse.stardust.common.error.InternalException;
import org.eclipse.stardust.common.error.LoginFailedException;
import org.eclipse.stardust.common.log.LogUtils;
import org.eclipse.stardust.common.utils.ejb.EjbProperties;
import org.eclipse.stardust.engine.api.ejb2.SecureSessionFactory;
import org.eclipse.stardust.engine.api.runtime.ServiceNotAvailableException;


/**
 * @author ubirkemeyer
 * @version $Revision$
 */
public class WeblogicSecureSessionFactory implements SecureSessionFactory
{
   public Object get(String jndiName, Class homeClass,
         Class remoteClass, Class[] creationArgTypes, final Object[] creationArgs,
         Map credentials, Map properties)
   {
      // TODO (kafka): use properties
      
      try
      {
         Hashtable<String, String> env = new Hashtable<String, String>();

         env.put(Context.INITIAL_CONTEXT_FACTORY, 
               Parameters.instance().getString(EjbProperties.INITIAL_CONTEXT_FACTORY, 
               "weblogic.jndi.WLInitialContextFactory"));
         env.put(Context.PROVIDER_URL, 
               Parameters.instance().getString(EjbProperties.JNDI_URL, 
               "t3://localhost:7001"));
         env.put(Context.SECURITY_PRINCIPAL, (String)credentials.get("user"));
         env.put(Context.SECURITY_CREDENTIALS, (String)credentials.get("password"));
         Context context = new InitialContext(env);

         Object rawHome = context.lookup(jndiName);
         LogUtils.traceObject(rawHome, false);
         Object home = PortableRemoteObject.narrow(rawHome, homeClass);
         LogUtils.traceObject(homeClass, false);
         Method creationMethod = homeClass.getMethod("create", creationArgTypes);

         return creationMethod.invoke(home, creationArgs);
      }
      catch (Throwable e)
      {
         boolean internal = true;
         
         if (e instanceof InvocationTargetException)
         {
            e = ((InvocationTargetException) e).getTargetException();
         }
         
         if (e instanceof RemoteException)
         {
            internal = false;
            if(((RemoteException) e).detail != null)
            {
               e = ((RemoteException) e).detail;
            }
         }
         
         if (e instanceof NamingSecurityException)
         {
            throw new LoginFailedException(e.getMessage(),
                  LoginFailedException.AUTHORIZATION_FAILURE);
         }
         
         if (e instanceof NamingException)
         {
            internal = false;
         }
         
         if (internal)
         {
            throw new InternalException("Failed to create session bean.", e);
         }
         else
         {
            throw new ServiceNotAvailableException(e.getMessage(), e);
         }
      }
   }
}
