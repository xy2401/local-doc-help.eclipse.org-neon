/*******************************************************************************
 * Copyright (c) 2012, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/
/*
 * $Id$
 * (C) 2000 - 2011 SunGard CSA LLC
 */
package org.eclipse.stardust.examples.authorization.ldap;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.namespace.QName;

import org.eclipse.stardust.engine.core.spi.security.DynamicParticipantSynchronizationProvider;
import org.eclipse.stardust.engine.core.spi.security.ExternalDepartmentConfiguration;
import org.eclipse.stardust.engine.core.spi.security.ExternalUserConfiguration;


/**
 * An example implementation of a DynamicParticipantSynchronizationProvider
 * synchronizing from an LDAP directory.
 *
 * @author ubirkemeyer
 * @version $Revision$
 */
public class LDAPSynchronizationProvider extends
      DynamicParticipantSynchronizationProvider
{
   public ExternalUserConfiguration provideUserConfiguration(String account)
   {
      ExternalUserConfiguration personConfig;

      final LDAPPerson ldapPerson = LDAPAdapter.instance().getPerson(account);
      if (null != ldapPerson && ldapPerson.isExisting())
      {
         personConfig = new UserConfig(ldapPerson);
      }
      else
      {
         personConfig = null;
      }

      return personConfig;
   }

   @Override
   public ExternalDepartmentConfiguration provideDepartmentConfiguration(
         String participantId, List<String> departmentKey)
   {
      LDAPDepartment ldapDept = LDAPAdapter.instance().getDepartment(participantId, departmentKey);
      if (ldapDept == null && participantId.startsWith("{"))
      {
         String localPart = QName.valueOf(participantId).getLocalPart();
         if (!localPart.equals(participantId))
         {
            ldapDept = LDAPAdapter.instance().getDepartment(localPart, departmentKey);
         }
      }
      return ldapDept == null ? null : new DepartmentConfig(ldapDept);
   }
   
   private static class UserConfig extends ExternalUserConfiguration
   {
      private final LDAPPerson ldapPerson;
      
      public UserConfig(final LDAPPerson ldapPerson)
      {
         if (ldapPerson == null)
         {
            throw new NullPointerException("LDAP person must not be null.");
         }
         
         this.ldapPerson = ldapPerson;
      }
      
      public String getFirstName()
      {
         return ldapPerson.getFirstName();
      }

      public String getLastName()
      {
         return ldapPerson.getLastName();
      }

      public String getDescription()
      {
         return ldapPerson.getDescription();
      }

      public String getEMail()
      {
         return ldapPerson.getEMail();
      }

      public Collection getGrantedModelParticipants()
      {
         return LDAPAdapter.instance().getParticipants(ldapPerson);
      }

      @Override
      public Set<GrantInfo> getModelParticipantsGrants()
      {
         return LDAPAdapter.instance().getModelParticipantsGrants(ldapPerson);
      }
      
      public Map getProperties()
      {
         return ldapPerson.getPropertyMap();
      }
   }
   
   private static class DepartmentConfig extends ExternalDepartmentConfiguration
   {
      private final LDAPDepartment ldapDept;
      
      public DepartmentConfig(final LDAPDepartment ldapDept)
      {
         if (ldapDept == null)
         {
            throw new NullPointerException("LDAP department must not be null.");
         }
         
         this.ldapDept = ldapDept;
      }
      
      @Override
      public String getName()
      {
         return ldapDept.getName();
      }
      
      @Override
      public String getDescription()
      {
         return ldapDept.getDescription();
      }
   }
}
