********************************************

Service Provider Interface Examples

Copyright (c) 2014 SunGard CSA LLC and others.
All rights reserved. This program and the accompanying materials
are made available under the terms of the Eclipse Public License v1.0
which accompanies this distribution, and is available at
_http://www.eclipse.org/legal/epl-v10.html
Contributors:
SunGard CSA LLC - initial API and implementation and/or initial documentation

********************************************

Our product provides example attribute classes and access point provider 
classes for data type and plain Java application configurations.

Content

The example contains two packages, one with provider classes for application 
types and one for data types.

Application Type

The package org.eclipse.stardust.engine.core.pojo.app contains the following 
plain Java application provider classes:

 * PlainJavaAccessPointProvider.java
 * PlainJavaApplicationInstance.java
 * PlainJavaValidator.java

Data Type

The package org.eclipse.stardust.engine.extensions.xml.data contains the 
following data type provider classes:

 * TypeSelectorDialog.java
 * XMLAccessPoint.java
 * XMLDataType.java
 * XMLDocumentPropertiesEditor.java
 * XMLValidator.java
 * XPathEditor.java
 * XPathEvaluator.java
