/*******************************************************************************

 * Copyright (c) 2012, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/
/*
 * $Id$
 * (C) 2000 - 2011 SunGard CSA LLC
 */
package org.eclipse.stardust.examples.authorization.properties;        

import java.util.Map;

import org.eclipse.stardust.common.CompareHelper;
import org.eclipse.stardust.common.error.ErrorCase;
import org.eclipse.stardust.common.error.LoginFailedException;
import org.eclipse.stardust.engine.core.spi.security.ExternalLoginProvider;
import org.eclipse.stardust.engine.core.spi.security.ExternalLoginResult;
 
/**
 * @author ubirkemeyer
 * @version $Revision$
 */
public class PropertyFileLoginService implements ExternalLoginProvider
{
   @Override
   public ExternalLoginResult login(String id, String password, Map properties)
   {
      PropertyRegistry registry = new PropertyRegistry();
      registry.load();
      boolean success = CompareHelper.areEqual(registry.getPassword(id), password);
      if (success)
      {
         return ExternalLoginResult.testifySuccess(properties);
      }
      else
      {
         return ExternalLoginResult.testifyFailure(new LoginFailedException(
               new ErrorCase("Login Failed Error Case")
               {
                  private static final long serialVersionUID = 1L;

                  public String toString()
                  {
                     return "Invalid user or password was incorrect.";
                  }
               }, LoginFailedException.INVALID_PASSWORD));
      }

   }
}
