/*******************************************************************************
 * Copyright (c) 2011, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * _http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/
package org.eclipse.stardust.examples.jfc;

import java.util.Date;

public class PersonDetails
{
    String name;
    String fname;
    String mname;
    String caddress;
    String paddress;
    String sex;
    Date dob;
    Long phoneno;
    Long mobileno;
    String companyName;
	Integer empID;
	String empInfo;
		
	public PersonDetails()
    {
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getFname()
    {
        return fname;
    }

    public void setFname(String fname)
    {
        this.fname = fname;
    }

    public String getMname()
    {
        return mname;
    }

    public void setMname(String mname)
    {
        this.mname = mname;
    }

    public String getCaddress()
    {
        return caddress;
    }

    public void setCaddress(String caddress)
    {
        this.caddress = caddress;
    }

    public String getPaddress()
    {
        return paddress;
    }

    public void setPaddress(String paddress)
    {
        this.paddress = paddress;
    }

    public String getSex()
    {
        return sex;
    }

    public void setSex(String sex)
    {
        this.sex = sex;
    }

    public Date getDob()
    {
        return dob;
    }

    public void setDob(Date dob)
    {
        this.dob = dob;
    }

    public Long getPhoneno()
    {
        return phoneno;
    }

    public void setPhoneno(Long phoneno)
    {
        this.phoneno = phoneno;
    }

    public Long getMobileno()
    {
        return mobileno;
    }

    public void setMobileno(Long mobileno)
    {
        this.mobileno = mobileno;
    }

    public String Submit()
    {
        return "submit";
    }
    public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public Integer getEmpID() {
		return empID;
	}

	public void setEmpID(Integer empID) {
		this.empID = empID;
	}  
	
	public String getEmpInfo() {
		return empInfo;
	}

	public void setEmpInfo(String empInfo) {
		this.empInfo = empInfo;
	}
		
}
