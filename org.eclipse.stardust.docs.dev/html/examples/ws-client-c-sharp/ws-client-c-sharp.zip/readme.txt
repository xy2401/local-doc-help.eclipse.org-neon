********************************************

WS C# Client Example

Copyright (c) 2014 SunGard CSA LLC and others.
All rights reserved. This program and the accompanying materials
are made available under the terms of the Eclipse Public License v1.0
which accompanies this distribution, and is available at
_http://www.eclipse.org/legal/epl-v10.html
Contributors:
SunGard CSA LLC - initial API and implementation and/or initial documentation

********************************************

This example contains the source code for three example implementations of a
C# Web Service client that communicate with a deployed product engine
which provides Web Services:

 * WsClientExampleApp
      - This example demonstrates running a tiny process
        using the WS API. Please note that a deployed
        model WsClientExampleModel.xpdl, which is shipped with this
        example as well, is necessary to run this sample application.
 * WsClientAuthExampleApp
      - This example demonstrates all permitted authentication mechanisms.
 * WsClientQueryExampleApp -
      - This example demonstrates how to use the Web Services Query API
        correctly: You should use classes of namespace
        com.infinity.bpm.api.query.stubs to
        do queries, whereas assembling of
        query elements (order criteria, policy and predicate) has to be done
        with classes of namespace com.infinity.bpm.api.query.

In order to build a custom WS Client the factory WsFactory may be
used to easily gain a reference to an exposed Web Service. To run
the examples the application configuration file WsClient.config has to be
used in the corresponding C# project and is bound to contain the properties
(host, port and context root) of the actual running Web Service.
