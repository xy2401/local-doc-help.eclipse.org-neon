/*******************************************************************************
 * Copyright (c) 2012, 2014 SunGard CSA LLC and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * SunGard CSA LLC - initial API and implementation and/or initial documentation
 *******************************************************************************/
/*
 * $Id: $
 * (C) 2000-2011 SunGard CSA LLC
 */
package org.eclipse.stardust.examples.authorization.properties;

import org.eclipse.stardust.common.StringUtils;
import org.eclipse.stardust.engine.core.spi.security.ExternalDepartmentConfiguration;


/**
 * @author nicolas.werlein
 * @version $Revision: $
 */
public class DepartmentConfiguration extends ExternalDepartmentConfiguration
{
   private final PropertyRegistry registry;
   private final String departmentKeyString;

   public DepartmentConfiguration(final PropertyRegistry registry,
         final String departmentKeyString)
   {
      if (registry == null)
         throw new NullPointerException("Registry must not be null.");
      if (departmentKeyString == null)
         throw new NullPointerException("Depratment ID must not be null.");
      if (StringUtils.isEmpty(departmentKeyString))
         throw new IllegalArgumentException("Department ID must not be empty.");
      
      this.registry = registry;
      this.departmentKeyString = departmentKeyString;
   }

   @Override
   public String getName()
   {
      return registry.getNameForDepartment(departmentKeyString);
   }
   
   @Override
   public String getDescription()
   {
      return registry.getDescriptionForDepartment(departmentKeyString);
   }
}
