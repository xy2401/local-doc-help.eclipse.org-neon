package org.eclipse.stardust.examples.errorcases;

import java.text.MessageFormat;

import org.eclipse.stardust.common.error.ErrorCase;
import org.eclipse.stardust.engine.api.runtime.BpmRuntimeErrorMessages;


public class ActivityInstanceMonitorErrorCase extends ErrorCase
{

   private static final long serialVersionUID = 1L;

   
   // Error Types
   public static final Args0 AIM_GENERIC_ERROR = newArgs0("CUST01000", ActivityInstanceMonitorErrorMessage.getString("CUST01000")); //$NON-NLS-1$ //$NON-NLS-2$
   public static final Args1 AIM_GENERIC_ERROR_WITH_SINGLE_ARG = newArgs1("CUST01010", ActivityInstanceMonitorErrorMessage.getString("CUST01010")); //$NON-NLS-1$ //$NON-NLS-2$   
   
   //
   
   private static final Object[] NONE = {};

   private final String defaultMessage;

   private final Object[] args;

   private ActivityInstanceMonitorErrorCase(String id)
   {
      this(id, null);
   }

   private ActivityInstanceMonitorErrorCase(String id, String defaultMessage)
   {
      this(id, defaultMessage, NONE);
   }

   private ActivityInstanceMonitorErrorCase(String code, String defaultMessage, Object msgArgs[])
   {
      super(code);

      this.defaultMessage = defaultMessage;
      this.args = msgArgs;
   }

   public String getDefaultMessage()
   {
      return defaultMessage;
   }

   public Object[] getMessageArgs()
   {
      return args;
   }

   public String toString()
   {
      return getId() + " - " + MessageFormat.format(getDefaultMessage(), args); //$NON-NLS-1$
   }
   
   public static Args0 newArgs0(String errorCode)
   {
      return new Args0(errorCode, BpmRuntimeErrorMessages.getString(errorCode));
   }


   public static Args0 newArgs0(String errorCode, String defaultMessage)
   {
      return new Args0(errorCode, defaultMessage);
   }   
   

   public static Args1 newArgs1(String errorCode)
   {
      return new Args1(errorCode, BpmRuntimeErrorMessages.getString(errorCode));
   }

   public static Args1 newArgs1(String errorCode, String defaultMessage)
   {
      return new Args1(errorCode, defaultMessage);
   }
   
   public static class Args0 extends AbstractErrorFactory
   {
      private Args0(String errorCode, String defaultMessage)
      {
         super(errorCode, defaultMessage);
      }

      public ActivityInstanceMonitorErrorCase raise()
      {
         return buildError(NONE);
      }
   }

   public static class Args1 extends AbstractErrorFactory
   {
      private Args1(String errorCode, String defaultMessage)
      {
         super(errorCode, defaultMessage);
      }

      public ActivityInstanceMonitorErrorCase raise(Object arg)
      {
         return buildError(new Object[] {arg});
      }

      public ActivityInstanceMonitorErrorCase raise(long arg)
      {
         return buildError(new Object[] {new Long(arg)});
      }
   }   
   
   static abstract class AbstractErrorFactory
   {
      private final String errorCode;

      private final String defaultMessage;

      protected AbstractErrorFactory(String errorCode, String defaultMessage)
      {
         this.errorCode = errorCode;
         this.defaultMessage = defaultMessage;
      }

      protected ActivityInstanceMonitorErrorCase buildError(Object[] args)
      {
         return new ActivityInstanceMonitorErrorCase(errorCode, defaultMessage, args);
      }

      public String getErrorCode()
      {
         return errorCode;
      }
   }   
   
}